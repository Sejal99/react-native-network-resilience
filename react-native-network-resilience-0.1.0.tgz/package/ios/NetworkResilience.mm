#import "NetworkResilience.h"

@implementation NetworkResilience
- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
    return std::make_shared<facebook::react::NativeNetworkResilienceSpecJSI>(params);
}

+ (NSString *)moduleName
{
  return @"NetworkResilience";
}

@end
