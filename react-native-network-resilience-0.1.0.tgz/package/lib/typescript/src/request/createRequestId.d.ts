export declare function createRequestId(): string;
//# sourceMappingURL=createRequestId.d.ts.map