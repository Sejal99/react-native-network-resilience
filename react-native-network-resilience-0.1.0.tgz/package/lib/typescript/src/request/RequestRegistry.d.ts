export declare class RequestRegistry {
    private readonly requests;
    has(key: string): boolean;
    get<T>(key: string): Promise<T> | undefined;
    set<T>(key: string, promise: Promise<T>): void;
    delete(key: string): void;
    clear(): void;
}
//# sourceMappingURL=RequestRegistry.d.ts.map