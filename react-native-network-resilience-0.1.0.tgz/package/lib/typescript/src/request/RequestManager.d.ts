import type { HttpTransport } from '../transport/HttpTransport.js';
import { RetryPolicy } from '../retry/RetryPolicy.js';
import type { RequestConfig } from '../types/index.js';
import type { ConnectivityProvider } from '../connectivity/ConnectivityProvider.js';
import { NetworkEventEmitter } from '../events/NetworkEventEmitter.js';
export declare class RequestManager {
    private readonly transport;
    private readonly retryPolicy;
    private readonly connectivityProvider?;
    private readonly waitForNetwork;
    private readonly connectivityTimeout;
    private readonly eventEmitter?;
    constructor(transport: HttpTransport, retryPolicy: RetryPolicy, connectivityProvider?: ConnectivityProvider | undefined, waitForNetwork?: boolean, connectivityTimeout?: number, eventEmitter?: NetworkEventEmitter | undefined);
    getMetrics(): import("../metrics/RequestMetrics.js").RequestMetrics[];
    execute<T>(config: RequestConfig): Promise<T>;
    private sleep;
}
//# sourceMappingURL=RequestManager.d.ts.map