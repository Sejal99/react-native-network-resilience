import type { RequestConfig } from '../types/index.js';
export declare function createRequestKey(config: RequestConfig): string;
//# sourceMappingURL=createRequestKey.d.ts.map