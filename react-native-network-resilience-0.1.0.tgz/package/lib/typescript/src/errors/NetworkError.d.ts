export type NetworkErrorCode = 'TIMEOUT' | 'NETWORK_ERROR' | 'HTTP_ERROR' | 'CANCELLED' | 'MAX_RETRIES_EXCEEDED' | 'NETWORK_UNAVAILABLE';
export declare class NetworkError extends Error {
    readonly code: NetworkErrorCode;
    readonly status?: number;
    readonly url?: string;
    readonly attempt?: number;
    constructor(message: string, options: {
        code: NetworkErrorCode;
        status?: number;
        url?: string;
        attempt?: number;
    });
}
//# sourceMappingURL=NetworkError.d.ts.map