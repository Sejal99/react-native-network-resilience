import type { ConnectivityProvider } from './ConnectivityProvider.js';
export declare class NetInfoConnectivityProvider implements ConnectivityProvider {
    private online;
    private readonly listeners;
    private unsubscribeNetInfo?;
    constructor();
    isOnline(): boolean;
    subscribe(listener: (online: boolean) => void): () => void;
    destroy(): void;
}
//# sourceMappingURL=NetInfoConnectivityProvider.d.ts.map