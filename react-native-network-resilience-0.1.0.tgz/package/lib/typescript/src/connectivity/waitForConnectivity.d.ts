import type { ConnectivityProvider } from './ConnectivityProvider.js';
export declare function waitForConnectivity(provider: ConnectivityProvider, timeout?: number): Promise<void>;
//# sourceMappingURL=waitForConnectivity.d.ts.map