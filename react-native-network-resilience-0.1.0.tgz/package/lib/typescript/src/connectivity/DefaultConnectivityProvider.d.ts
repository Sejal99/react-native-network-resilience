import type { ConnectivityProvider } from './ConnectivityProvider.js';
export declare class DefaultConnectivityProvider implements ConnectivityProvider {
    private online;
    private readonly listeners;
    isOnline(): boolean;
    subscribe(listener: (online: boolean) => void): () => void;
    setOnline(online: boolean): void;
}
//# sourceMappingURL=DefaultConnectivityProvider.d.ts.map