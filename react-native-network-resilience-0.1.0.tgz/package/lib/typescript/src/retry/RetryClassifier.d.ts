export declare class RetryClassifier {
    shouldRetry(status?: number): boolean;
}
//# sourceMappingURL=RetryClassifier.d.ts.map