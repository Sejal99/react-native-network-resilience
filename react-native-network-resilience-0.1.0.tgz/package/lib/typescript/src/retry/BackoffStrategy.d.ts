export interface BackoffOptions {
    initialDelay: number;
    maxDelay: number;
    jitter: boolean;
}
export declare function calculateBackoff(attempt: number, options: BackoffOptions): number;
//# sourceMappingURL=BackoffStrategy.d.ts.map