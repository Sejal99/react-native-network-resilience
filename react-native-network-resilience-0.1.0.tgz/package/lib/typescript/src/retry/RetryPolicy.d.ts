import type { RetryConfig } from '../types/index.js';
export declare class RetryPolicy {
    private readonly config;
    private readonly classifier;
    constructor(config: RetryConfig);
    shouldRetry(error: unknown, attempt: number): boolean;
    getDelay(attempt: number): number;
}
//# sourceMappingURL=RetryPolicy.d.ts.map