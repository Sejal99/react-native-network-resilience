import type { HttpTransport } from './HttpTransport.js';
import type { RequestConfig } from '../types/index.js';
export declare class FetchTransport implements HttpTransport {
    request<T>(config: RequestConfig): Promise<T>;
}
//# sourceMappingURL=FetchTransport.d.ts.map