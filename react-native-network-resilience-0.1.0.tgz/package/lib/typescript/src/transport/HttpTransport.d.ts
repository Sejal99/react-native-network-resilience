import type { RequestConfig } from '../types/index.js';
export interface HttpTransport {
    request<T>(config: RequestConfig): Promise<T>;
}
//# sourceMappingURL=HttpTransport.d.ts.map