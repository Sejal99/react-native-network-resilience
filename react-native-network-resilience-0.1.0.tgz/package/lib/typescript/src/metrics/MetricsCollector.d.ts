import type { NetworkEvent } from '../events/NetworkEvent.js';
import type { RequestMetrics } from './RequestMetrics.js';
export declare class MetricsCollector {
    private readonly requests;
    private readonly completed;
    handleEvent(event: NetworkEvent): void;
    getMetrics(): RequestMetrics[];
    private complete;
}
//# sourceMappingURL=MetricsCollector.d.ts.map