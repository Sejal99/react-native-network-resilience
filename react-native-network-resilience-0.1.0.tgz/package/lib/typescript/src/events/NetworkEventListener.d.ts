import type { NetworkEvent } from './NetworkEvent.js';
export type NetworkEventListener = (event: NetworkEvent) => void;
//# sourceMappingURL=NetworkEventListener.d.ts.map