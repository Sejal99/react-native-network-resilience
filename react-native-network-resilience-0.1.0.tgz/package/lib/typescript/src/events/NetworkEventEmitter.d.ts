import type { NetworkEvent } from './NetworkEvent.js';
import type { NetworkEventListener } from './NetworkEventListener.js';
export declare class NetworkEventEmitter {
    private readonly listener?;
    private readonly metricsCollector;
    constructor(listener?: NetworkEventListener | undefined);
    emit(event: NetworkEvent): void;
    getMetrics(): import("../metrics/RequestMetrics.js").RequestMetrics[];
}
//# sourceMappingURL=NetworkEventEmitter.d.ts.map