import type { ConnectivityProvider } from '../connectivity/ConnectivityProvider.js';
import { RequestManager } from '../request/RequestManager.js';
import { OfflineQueue } from './OfflineQueue.js';
export declare class QueueProcessor {
    private readonly queue;
    private readonly requestManager;
    private readonly connectivityProvider;
    private processing;
    constructor(queue: OfflineQueue, requestManager: RequestManager, connectivityProvider: ConnectivityProvider);
    start(): () => void;
    process(): Promise<void>;
}
//# sourceMappingURL=QueueProcessor.d.ts.map