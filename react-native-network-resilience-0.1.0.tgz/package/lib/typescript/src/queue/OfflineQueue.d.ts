import type { RequestConfig } from '../types/index.js';
export interface QueuedRequest {
    id: string;
    config: RequestConfig;
    createdAt: number;
}
export declare class OfflineQueue {
    private readonly storage;
    private queue;
    constructor();
    add(config: RequestConfig): string;
    getAll(): QueuedRequest[];
    remove(id: string): void;
    clear(): void;
    get size(): number;
    private load;
    private persist;
}
//# sourceMappingURL=OfflineQueue.d.ts.map