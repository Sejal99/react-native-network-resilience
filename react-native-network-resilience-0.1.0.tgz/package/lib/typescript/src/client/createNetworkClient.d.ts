import { NetworkClient } from './NetworkClient.js';
import type { NetworkClientConfig } from '../types/index.js';
export declare function createNetworkClient(config?: NetworkClientConfig): NetworkClient;
//# sourceMappingURL=createNetworkClient.d.ts.map