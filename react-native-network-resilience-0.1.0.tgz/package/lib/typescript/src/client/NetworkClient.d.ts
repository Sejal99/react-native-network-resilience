import { RequestManager } from '../request/RequestManager.js';
import type { NetworkClientConfig, RequestConfig } from '../types/index.js';
import { RequestRegistry } from '../request/RequestRegistry.js';
import type { ConnectivityProvider } from '../connectivity/ConnectivityProvider.js';
import { OfflineQueue } from '../queue/OfflineQueue.js';
export declare class NetworkClient {
    private readonly config;
    private readonly requestManager;
    private readonly requestRegistry;
    private readonly connectivityProvider?;
    private readonly offlineQueue?;
    constructor(config: NetworkClientConfig, requestManager: RequestManager, requestRegistry: RequestRegistry, connectivityProvider?: ConnectivityProvider | undefined, offlineQueue?: OfflineQueue | undefined);
    getMetrics(): import("../metrics/RequestMetrics.js").RequestMetrics[];
    get<T>(url: string, options?: Omit<RequestConfig, 'url' | 'method'>): Promise<T>;
    post<T>(url: string, body?: unknown, options?: Omit<RequestConfig, 'url' | 'method' | 'body'>): Promise<T>;
    put<T>(url: string, body?: unknown, options?: Omit<RequestConfig, 'url' | 'method' | 'body'>): Promise<T>;
    patch<T>(url: string, body?: unknown, options?: Omit<RequestConfig, 'url' | 'method' | 'body'>): Promise<T>;
    delete<T>(url: string, options?: Omit<RequestConfig, 'url' | 'method'>): Promise<T>;
    private request;
    private buildUrl;
}
//# sourceMappingURL=NetworkClient.d.ts.map